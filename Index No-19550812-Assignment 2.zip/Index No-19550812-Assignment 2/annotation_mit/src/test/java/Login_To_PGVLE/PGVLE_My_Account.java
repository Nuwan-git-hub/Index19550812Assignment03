package Login_To_PGVLE;

import org.openqa.selenium.WebDriver;

public class PGVLE_My_Account extends BasePage{

    public  PGVLE_My_Account(WebDriver driver)
    {
        super(driver);
    }

}
