package Login_To_PGVLE;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class BasePage {

protected WebDriver driver;

public BasePage(WebDriver driver)
{
 this.driver=driver;

}

public  WordPressHome loadURL(String url)
{
    driver.get((url));
    return PageFactory.initElements(driver,WordPressHome.class);
}

public  PGVLE_Home loadURL1(String url)
{
 driver.get((url));
 return PageFactory.initElements(driver,PGVLE_Home.class);
}


}
