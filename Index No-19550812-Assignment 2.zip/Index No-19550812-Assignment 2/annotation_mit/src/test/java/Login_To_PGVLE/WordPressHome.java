package Login_To_PGVLE;

import org.apache.xmlbeans.impl.xb.xsdschema.FieldDocument;
import org.apache.xmlbeans.impl.xb.xsdschema.SelectorDocument;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class WordPressHome extends BasePage
{


    @FindBy(xpath = "/html/body/div[2]/nav/ul[2]/li[1]/a")
    public WebElement LoginButton;


    public  WordPressHome(WebDriver driver)

    {
        super(driver);
    }


    public  WordPressLogin clickLoginButton()
    {

       LoginButton.click();

       return PageFactory.initElements(driver,WordPressLogin.class);
    }

}
