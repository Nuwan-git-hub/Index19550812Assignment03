package Login_To_PGVLE;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PGVLE_Login extends BasePage{

    @FindBy(xpath = "//input[@id='username']")
    public WebElement MyUserName;

    @FindBy(xpath = "//input[@id='password']")
    public WebElement MyPassword;

    @FindBy(xpath = "//*[@id=\"loginbutton\"]")
    public WebElement LoginButton;



    public  PGVLE_Login(WebDriver driver)
    {
        super(driver);
    }


    public void InsertUserName(String UserName)
    {
        MyUserName.sendKeys(UserName);
    }

    public void InsertPassword(String Password)
    {
        MyUserName.sendKeys(Password);
    }

    public  PGVLE_My_Account clickPGVLE_LoginButton()
    {

        LoginButton.click();

        return PageFactory.initElements(driver,PGVLE_My_Account.class);
    }


}
