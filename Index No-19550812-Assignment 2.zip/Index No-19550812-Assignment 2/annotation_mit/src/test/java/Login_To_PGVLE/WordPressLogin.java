package Login_To_PGVLE;

import org.openqa.selenium.WebDriver;

public class WordPressLogin extends BasePage {

    public  WordPressLogin(WebDriver driver)
    {
        super(driver);
    }



}
