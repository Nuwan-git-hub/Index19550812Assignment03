package Login_To_PGVLE;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PGVLE_Home extends BasePage {

    @FindBy(xpath = "/html/body/div[2]/nav/ul[2]/li[2]/div/span/a")
    public WebElement PGVLE_LoginButton;



    public  PGVLE_Home(WebDriver driver)
    {
        super(driver);
    }


    public  PGVLE_Login clickPGVLELoginButton()
    {

        PGVLE_LoginButton.click();

        return PageFactory.initElements(driver,PGVLE_Login.class);
    }

}
