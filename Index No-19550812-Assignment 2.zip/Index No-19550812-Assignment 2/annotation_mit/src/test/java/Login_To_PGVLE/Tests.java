package Login_To_PGVLE;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import java.io.File;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFSheet;

public class Tests extends Utilities
{
    @Test

    public void Load_WordPress()
    {

        BasePage basePage= PageFactory.initElements(driver,BasePage.class);
        WordPressHome wordpressHome = basePage.loadURL("https://wordpress.com/");

        WordPressLogin wordpressLogin = wordpressHome.clickLoginButton();

    }


    @Test


    public void readExcel() throws Exception
    {
        BasePage basePage= PageFactory.initElements(driver,BasePage.class);
        PGVLE_Home pgvle_Home = basePage.loadURL1("https://pgvle.ucsc.cmb.ac.lk/pgvle_23/");

        PGVLE_Login pgvle_Login = pgvle_Home.clickPGVLELoginButton();

       
        String excelPath = ".\\Excel Files\\TestData.xlsx";

        String fileNameString = "TestData";
        String sheetName = "Test";

        File file = new File(excelPath);
        FileInputStream fis = new FileInputStream(file);

        XSSFWorkbook wb = new XSSFWorkbook(fis);

        XSSFSheet sheet = wb.getSheet(sheetName);

        String data3 = sheet.getRow(1).getCell(0).getStringCellValue();
        String data4 = sheet.getRow(1).getCell(1).getStringCellValue();


        pgvle_Login.InsertUserName(data3);
        pgvle_Login.InsertPassword(data4);
        PGVLE_My_Account pgvle_my_Account = pgvle_Login.clickPGVLE_LoginButton();

    }


}
