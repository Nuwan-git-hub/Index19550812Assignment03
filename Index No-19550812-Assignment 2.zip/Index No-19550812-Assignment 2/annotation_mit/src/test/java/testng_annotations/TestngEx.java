package testng_annotations;

import org.testng.annotations.*;

public class TestngEx {

@BeforeSuite
public void beforeSuite(){

    System.out.println("Before Suite");

}


@AfterSuite
public void afterSuite(){

    System.out.println("After Suite");

}

@BeforeClass
public void beforeClass(){

    System.out.println("Before Class");

}

@AfterClass
public void afterClass(){

    System.out.println("After Class");

}

@BeforeMethod

public void beforeMethod(){

    System.out.println("Before Method");

}

@AfterMethod
public void afterMethod(){

    System.out.println("After Method");

}

@BeforeTest
public void beforeTest(){

    System.out.println("Before Test");

}

@AfterTest
public void afterTest(){

    System.out.println("After Test");

}


    @Test(priority = 1)

    public void one(){

System.out.println("One");

    }

    @Test

    public void two(){

        System.out.println("two");

    }

    @Test

    public void three(){

        System.out.println("three");

    }

    @Test

    public void four(){

        System.out.println("four");

    }
}
